# frozen_string_literal: true
module Asciidoctor
  VERSION = '2.0.16'
end
