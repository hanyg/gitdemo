module Asciidoctor
module Revealjs
  VERSION = '4.1.0'
end
end
