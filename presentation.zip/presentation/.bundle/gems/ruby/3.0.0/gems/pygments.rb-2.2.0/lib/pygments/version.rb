# frozen_string_literal: true

module Pygments
  VERSION = '2.2.0'
end
