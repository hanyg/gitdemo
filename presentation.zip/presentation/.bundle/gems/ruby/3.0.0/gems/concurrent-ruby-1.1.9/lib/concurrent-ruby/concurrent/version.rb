module Concurrent
  VERSION = '1.1.9'
end
