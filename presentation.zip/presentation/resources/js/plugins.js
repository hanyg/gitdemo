{ src: 'revealjs-plugins/reveal.js-menu/menu.js' },
{ src: 'revealjs-plugins/chalkboard/chalkboard.js' },
{ src: 'revealjs-plugins/customcontrols/plugin.js' }

